export const theme = {
    colors: {
      white: "#ffffff",
      btn: "#ff0000", // Replace with your desired color
    },
    
  };
  